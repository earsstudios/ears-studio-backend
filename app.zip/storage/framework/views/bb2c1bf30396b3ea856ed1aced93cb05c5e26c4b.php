<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Semua Report</title>
</head>
<body>
    <h1>Laporan Semua Report</h1>

    <table border="1" cellpadding="5" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Program</th>
                <th>Jumlah Penerima Manfaat</th>
                <th>Provinsi</th>
                <th>Kota</th>
                <th>Kecamatan</th>
                <th>Tanggal Distribusi</th>
                <th>Catatan Tambahan</th>
                <th>Status</th>
                <th>Alasan Penolakan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($report->program_name); ?></td>
                    <td><?php echo e($report->beneficiaries); ?></td>
                    <td><?php echo e($report->province); ?></td>
                    <td><?php echo e($report->city); ?></td>
                    <td><?php echo e($report->district); ?></td>
                    <td><?php echo e($report->distribution_date->format('d-m-Y')); ?></td>
                    <td><?php echo e($report->additional_notes); ?></td>
                    <td><?php echo e($report->status); ?></td>
                    <td><?php echo e($report->rejection_reason); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH D:\Project\TES Project\aplikasi-monitoring\resources\views/pdf/reports.blade.php ENDPATH**/ ?>